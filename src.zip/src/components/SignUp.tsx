import React from 'react';
import { Link } from 'react-router-dom';
import styled from 'styled-components';

const SignUpContainer = styled.div`
  max-width: 400px;
  margin: 0 auto;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 5px;
`;

const SignUpForm = styled.form`
  display: flex;
  flex-direction: column;
`;

const InputField = styled.input`
  margin-bottom: 10px;
  padding: 8px;
  border: 1px solid #ccc;
  border-radius: 3px;
`;

const SubmitButton = styled.button`
  padding: 10px;
  background-color: #28a745;
  color: #fff;
  border: none;
  border-radius: 3px;
  cursor: pointer;

  &:hover {
    background-color: #218838;
  }
`;

const SignInLink = styled(Link)`
  margin-top: 10px;
  color: #28a745;
  text-decoration: none;

  &:hover {
    text-decoration: underline;
  }
`;

const SignUp: React.FC = () => {
  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    // Handle registration logic
  };

  return (
    <SignUpContainer>
      <h2>Sign Up</h2>
      <SignUpForm onSubmit={handleSubmit}>
        <InputField type="text" placeholder="Username" />
        <InputField type="email" placeholder="Email" />
        <InputField type="password" placeholder="Password" />
        <SubmitButton type="submit">Sign Up</SubmitButton>
      </SignUpForm>
      <SignInLink to="/signin">Already have an account? Sign In</SignInLink>
    </SignUpContainer>
  );
};

export default SignUp;
