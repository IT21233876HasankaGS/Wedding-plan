import React from 'react';
import { Container, Header, Paragraph, Image } from './StyledComponents';
import weddingImage from '../images/wedding.jpg';

const Home: React.FC = () => {
  return (
    <Container>
      <Header>Welcome to Our Wedding</Header>
      <Image src={weddingImage} alt="Wedding" />
      <Paragraph>We're so excited to celebrate our special day with you!</Paragraph>
    </Container>
  );
};

export default Home;

