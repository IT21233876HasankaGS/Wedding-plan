import React, { useState } from 'react';
import { Container, Header, Paragraph } from './StyledComponents';
import { Form, Button } from 'react-bootstrap';

const RSVP: React.FC = () => {
  const [name, setName] = useState('');
  const [attending, setAttending] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('RSVP submitted:', { name, attending });
    // Here you would typically send the RSVP data to a server
  };

  return (
    <Container>
      <Header>RSVP</Header>
      <Form onSubmit={handleSubmit}>
        <Form.Group controlId="formName">
          <Form.Label>Name</Form.Label>
          <Form.Control type="text" value={name} onChange={(e) => setName(e.target.value)} required />
        </Form.Group>
        <Form.Group controlId="formAttending" className="mt-3">
          <Form.Label>Attending</Form.Label>
          <Form.Select value={attending} onChange={(e) => setAttending(e.target.value)} required>
            <option value="">Select</option>
            <option value="yes">Yes</option>
            <option value="no">No</option>
          </Form.Select>
        </Form.Group>
        <Button variant="primary" type="submit" className="mt-3">Submit</Button>
      </Form>
    </Container>
  );
};

export default RSVP;
