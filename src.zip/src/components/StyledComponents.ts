import styled from 'styled-components';

export const Container = styled.div`
  margin: 0 auto;
  max-width: 1200px;
  padding: 20px;
  background-color: #fff;
`;

export const Header = styled.h1`
  color: #333;
  text-align: center;
  margin-bottom: 20px;
`;

export const Paragraph = styled.p`
  color: #666;
  font-size: 1.2em;
  line-height: 1.5;
  text-align: center;
`;

export const Image = styled.img`
  width: 100%; /* Adjust the width as needed */
  max-width: 800px; /* Set a maximum width */
  height: auto; /* Maintain the aspect ratio */
  border-radius: 10px;
  display: block; /* Center the image */
  margin: 0 auto 20px; /* Add space below the image */
`;
