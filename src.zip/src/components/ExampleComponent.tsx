import React from 'react';
import styled from 'styled-components';
import { useTheme } from './ThemeProvider'; // Adjust path as necessary

const Container = styled.div`
  background-color: ${(props) => (props.theme.mode === 'dark' ? '#333' : '#fff')};
  color: ${(props) => (props.theme.mode === 'dark' ? '#fff' : '#333')};
  padding: 20px;
`;

const ExampleComponent: React.FC = () => {
  const { darkMode } = useTheme(); // Only need darkMode here

  return (
    <Container>
      <h1>{darkMode ? 'Dark Mode' : 'Light Mode'}</h1>
      <p>This container changes color based on the theme mode.</p>
    </Container>
  );
};

export default ExampleComponent;
