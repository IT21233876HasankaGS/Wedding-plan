import React from 'react';
import { Link } from 'react-router-dom';
import styled from 'styled-components';

const SignInContainer = styled.div`
  max-width: 400px;
  margin: 0 auto;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 5px;
`;

const SignInForm = styled.form`
  display: flex;
  flex-direction: column;
`;

const InputField = styled.input`
  margin-bottom: 10px;
  padding: 8px;
  border: 1px solid #ccc;
  border-radius: 3px;
`;

const SubmitButton = styled.button`
  padding: 10px;
  background-color: #007bff;
  color: #fff;
  border: none;
  border-radius: 3px;
  cursor: pointer;

  &:hover {
    background-color: #0056b3;
  }
`;

const SignUpLink = styled(Link)`
  margin-top: 10px;
  color: #007bff;
  text-decoration: none;

  &:hover {
    text-decoration: underline;
  }
`;

const SignIn: React.FC = () => {
  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    // Handle authentication logic
  };

  return (
    <SignInContainer>
      <h2>Sign In</h2>
      <SignInForm onSubmit={handleSubmit}>
        <InputField type="email" placeholder="Email" />
        <InputField type="password" placeholder="Password" />
        <SubmitButton type="submit">Sign In</SubmitButton>
      </SignInForm>
      <SignUpLink to="/signup">Don't have an account? Sign Up</SignUpLink>
    </SignInContainer>
  );
};

export default SignIn;
