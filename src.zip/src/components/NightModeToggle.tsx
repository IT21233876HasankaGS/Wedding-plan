import React from 'react';
import { useTheme } from '../ThemeProvider';
import styled from 'styled-components';

const ToggleButton = styled.button`
  background-color: transparent;
  border: none;
  cursor: pointer;
  color: inherit;
  font-size: 16px;
`;

const NightModeToggle: React.FC = () => {
  const { darkMode, toggleTheme } = useTheme();

  return (
    <ToggleButton onClick={toggleTheme}>
      {darkMode ? 'Light Mode' : 'Dark Mode'}
    </ToggleButton>
  );
};

export default NightModeToggle;
