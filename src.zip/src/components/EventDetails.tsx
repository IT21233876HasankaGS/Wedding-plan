import React from 'react';
import { Container, Header, Paragraph } from './StyledComponents';

const EventDetails: React.FC = () => {
  return (
    <Container>
      <Header>Event Details</Header>
      <Paragraph>Date: June 25, 2024</Paragraph>
      <Paragraph>Time: 4:00 PM</Paragraph>
      <Paragraph>Location: Beautiful Venue, City, State</Paragraph>
    </Container>
  );
};

export default EventDetails;
