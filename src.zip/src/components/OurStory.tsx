import React from 'react';
import { Container, Header, Paragraph } from './StyledComponents';

const OurStory: React.FC = () => {
  return (
    <Container>
      <Header>Our Story</Header>
      <Paragraph>How we met, our journey together, and the proposal story.</Paragraph>
    </Container>
  );
};

export default OurStory;
