import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import Home from './components/Home';
import OurStory from './components/OurStory';
import EventDetails from './components/EventDetails';
import RSVP from './components/RSVP';
import SignIn from './components/SignIn';
import SignUp from './components/SignUp';
import NightModeToggle from './components/NightModeToggle';
import ThemeProvider from './ThemeProvider'; // Assuming ThemeProvider is correctly implemented
import { Container } from 'react-bootstrap';
import styled from 'styled-components';

const Navbar = styled.nav`
  background-color: #333;
  padding: 10px 20px;
  margin-bottom: 20px;
  display: flex;
  justify-content: space-between;
`;

const NavList = styled.ul`
  list-style-type: none;
  padding: 0;
  display: flex;
`;

const NavItem = styled.li`
  margin: 0 10px;
`;

const NavLinkStyled = styled(Link)`
  color: #fff;
  text-decoration: none;

  &:hover {
    text-decoration: underline;
  }
`;


const App: React.FC = () => {
  return (
    <ThemeProvider>
      <Router>
        <Navbar>
          <NavList>
            <NavItem>
              <NavLinkStyled to="/">Home</NavLinkStyled>
            </NavItem>
            <NavItem>
              <NavLinkStyled to="/our-story">Our Story</NavLinkStyled>
            </NavItem>
            <NavItem>
              <NavLinkStyled to="/event-details">Event Details</NavLinkStyled>
            </NavItem>
            <NavItem>
              <NavLinkStyled to="/rsvp">RSVP</NavLinkStyled>
            </NavItem>
            <NavItem>
              <NavLinkStyled to="/signin">Sign In</NavLinkStyled>
            </NavItem>
            <NavItem>
              <NavLinkStyled to="/signup">Sign Up</NavLinkStyled>
            </NavItem>
          </NavList>
          <NightModeToggle /> {/* Assuming NightModeToggle is correctly implemented */}
        </Navbar>
        <Container>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/our-story" element={<OurStory />} />
            <Route path="/event-details" element={<EventDetails />} />
            <Route path="/rsvp" element={<RSVP />} />
            <Route path="/signin" element={<SignIn />} />
            <Route path="/signup" element={<SignUp />} />
          </Routes>
        </Container>
      </Router>
    </ThemeProvider>
  );
};

export default App;
